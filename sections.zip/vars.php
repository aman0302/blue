<?php

$parent_nav_items=array("academic"=>"Academic Genie","rent"=>"Rent Space","travel"=>"Plan Trip","food"=>"Drink'n Eat","events"=>"Events");
$rent_nav_items=array("portfolio"=>"Academic ","about"=>"Rent ","contact"=>"Plan Trip","about2"=>"Events","portfolio2"=>"Drink'n Eat");

?>
<?php
    include 'vars.php';
    include 'nav.php';
    include 'headerFooter.php';
    include 'sections.php';  
?>